import { pgTable, serial, text, timestamp, integer, boolean } from "drizzle-orm/pg-core";

export const reviews = pgTable("reviews", {
  id: serial().primaryKey(),
  name: text().notNull(),
  location: text().notNull().default(""),
  occasion: text().notNull().default(""),
  rating: integer().notNull().default(5),
  quote: text().notNull(),
  approved: boolean().notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});
