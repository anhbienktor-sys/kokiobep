# The Ember & Oak — Artisan Café Website

A full-featured café and restaurant website for The Ember & Oak, built with TanStack Start, React, and Tailwind CSS v4. Deployed on Netlify.

## Features

- **Home** — Hero section, philosophy, featured menu items, testimonial quote, private hire CTA, opening hours
- **Menu** — Full categorised menu (coffee, breakfast, brunch, lunch, pastries) with dietary badges and sticky category navigation
- **Order** — Click & collect ordering with an in-browser cart; order submitted via Netlify Forms
- **Contact** — Contact form with validation, submitted via Netlify Forms
- **Location** — OpenStreetMap embed, transport information, accessibility details, full opening hours
- **Private Hire** — Event type showcase, detailed quote request form, offsite catering section
- **Quotes** — Masonry testimonials grid with occasion filtering, plus a "leave a review" form

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | [TanStack Start](https://tanstack.com/start) (React 19 + Vite) |
| Routing | TanStack Router (file-based) |
| Styling | Tailwind CSS v4 + custom CSS variables |
| Typography | Google Fonts — Cormorant Garamond + Jost |
| Forms | Netlify Forms (all four forms) |
| Deployment | Netlify (SSR via Netlify Functions) |

## Running Locally

```bash
npm install
npm run dev
```

The dev server starts at http://localhost:3000.

For full Netlify feature emulation (forms, edge functions):

```bash
netlify dev --port 8889
```

> **Note:** Netlify Forms do not work in local dev. Deploy to Netlify to test form submissions.

## Environment

No environment variables are required for the base site.
