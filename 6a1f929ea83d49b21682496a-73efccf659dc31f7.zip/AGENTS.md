# AGENTS.md — The Ember & Oak

Project context for AI agents working on this codebase.

## What This Project Is

A café and restaurant marketing + utility website. It is a TanStack Start SSR app deployed on Netlify. The business is The Ember & Oak Café, Ashford, Kent.

## Key Technologies

- **TanStack Start** with file-based routing via TanStack Router
- **React 19** with hooks; no external state management library
- **Tailwind CSS v4** — utility classes are used in JSX, but the design system lives in `src/styles.css` (CSS custom properties + utility classes)
- **Netlify Forms** — all form submissions go through Netlify Forms. Static skeletons are in `public/__forms.html`
- **Google Fonts** — loaded via `@import` in `src/styles.css`

## Directory Structure

```
src/
  routes/          # File-based pages (one file = one route)
    __root.tsx     # HTML shell + global Nav + Footer layout
    index.tsx      # Home page (/)
    menu.tsx       # /menu
    order.tsx      # /order
    contact.tsx    # /contact
    location.tsx   # /location
    hire.tsx       # /hire
    quotes.tsx     # /quotes
  data/
    menu.ts        # All menu items and category definitions
    testimonials.ts # Testimonial data
  styles.css       # Global styles, CSS variables, design system

public/
  __forms.html     # Netlify Forms static skeletons (required for form detection)
```

## Design System

All design tokens are CSS custom properties defined in `src/styles.css`:

- `--ember` / `--ember-deep` — primary terracotta brand colour
- `--oak` / `--bark` — dark brown shades for text
- `--cream` / `--parchment` — warm off-white backgrounds
- `--gold` — muted gold accent (used for headings on dark backgrounds)
- `--ash` / `--smoke` — muted text and border colours
- `--ink` — near-black for dark section backgrounds

Typography:
- Display/headings: `'Cormorant Garamond', serif`
- Body/UI: `'Jost', sans-serif`

## Routing Conventions

Routes follow TanStack Router file-based conventions. Each route file exports `Route = createFileRoute('/path')({ component })`. The root route uses both `shellComponent` (HTML shell) and `component` (layout with Nav + Outlet + Footer).

## Netlify Forms

Four forms are registered: `contact`, `order`, `hire`, `review`. All use AJAX `fetch` with `application/x-www-form-urlencoded` encoding and post to `/__forms.html`. The static skeleton at `public/__forms.html` must be kept in sync with any field changes.

## Key Decisions

- **No database**: This site is purely informational + form collection. No persistent data storage is needed. If order management or CMS is added, use Netlify Database (`@netlify/database`).
- **Client-side cart**: The order page cart state is React `useState` — it resets on page refresh, which is acceptable for a click & collect workflow where confirmation is via email.
- **Inline styles**: Most component-level styles use inline `style={}` props rather than Tailwind utility classes for layout and spacing. This is intentional — the design is bespoke and avoids class proliferation.
- **No routing for products**: Menu items are not routed individually. They live in `src/data/menu.ts` and are filtered client-side.
