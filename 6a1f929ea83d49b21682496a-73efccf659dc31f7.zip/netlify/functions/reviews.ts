import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { reviews } from "../../db/schema.js";
import { desc, eq } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const rows = await db
      .select()
      .from(reviews)
      .where(eq(reviews.approved, true))
      .orderBy(desc(reviews.createdAt))
      .limit(30);
    return Response.json(rows);
  }

  if (req.method === "POST") {
    const body = await req.json();
    const { name, location, occasion, rating, quote } = body;

    if (!name || !quote) {
      return new Response("Missing required fields", { status: 400 });
    }

    const [review] = await db
      .insert(reviews)
      .values({
        name: String(name).trim(),
        location: String(location || "").trim(),
        occasion: String(occasion || "").trim(),
        rating: Math.min(5, Math.max(1, parseInt(String(rating)) || 5)),
        quote: String(quote).trim(),
      })
      .returning();

    return Response.json(review, { status: 201 });
  }

  if (req.method === "DELETE") {
    const url = new URL(req.url);
    const idStr = url.searchParams.get("id");
    const id = idStr ? parseInt(idStr) : null;

    if (!id || isNaN(id)) {
      return new Response("Missing or invalid review ID", { status: 400 });
    }

    try {
      await db.delete(reviews).where(eq(reviews.id, id));
      return new Response(null, { status: 204 });
    } catch (err: any) {
      return new Response(err.message || "Failed to delete review", { status: 500 });
    }
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/reviews",
};
