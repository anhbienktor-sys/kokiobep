CREATE TABLE "reviews" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"location" text DEFAULT '' NOT NULL,
	"occasion" text DEFAULT '' NOT NULL,
	"rating" integer DEFAULT 5 NOT NULL,
	"quote" text NOT NULL,
	"approved" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now()
);
