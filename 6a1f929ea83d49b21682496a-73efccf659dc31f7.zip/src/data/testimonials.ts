export interface Testimonial {
  id: string
  name: string
  location: string
  rating: number
  quote: string
  date: string
  occasion?: string
}

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Linh Nguyen',
    location: 'London',
    rating: 5,
    quote: 'The egg coffee took me straight back to Hanoi. It\'s the real thing — silky, sweet, and deeply comforting. I make the trip just for this. Nothing else in the UK comes close.',
    date: 'April 2026',
    occasion: 'Regular visit',
  },
  {
    id: '2',
    name: 'James & Sophie Carter',
    location: 'Ashford',
    rating: 5,
    quote: 'We had our engagement celebration catered by KoKio Bếp and our guests are still talking about the food. The Phở was incredible and the bánh mì were gone within minutes. Genuinely memorable.',
    date: 'March 2026',
    occasion: 'Private hire',
  },
  {
    id: '3',
    name: 'David Park',
    location: 'Canterbury',
    rating: 5,
    quote: 'As someone who grew up in Ho Chi Minh City, I was sceptical — but the coconut coffee and avocado smoothie are absolutely authentic. The phin drip method, the condensed milk ratio. They know what they\'re doing.',
    date: 'February 2026',
    occasion: 'Regular visit',
  },
  {
    id: '4',
    name: 'Emma Hartley',
    location: 'Folkestone',
    rating: 5,
    quote: 'The salted coffee converted me completely. I had no idea what to expect but it\'s now my go-to order every single visit. The staff are warm, the space is beautiful, and the food is always fresh.',
    date: 'March 2026',
    occasion: 'Weekend brunch',
  },
  {
    id: '5',
    name: 'Minh Tran',
    location: 'Ashford',
    rating: 5,
    quote: 'I come in most mornings before work and the team always remember my order — Kokio Special Iced Coffee with extra condensed milk. That kind of warmth is rare and it matters. This place has genuine soul.',
    date: 'January 2026',
    occasion: 'Regular visit',
  },
  {
    id: '6',
    name: 'Sarah & Tom Bishop',
    location: 'Maidstone',
    rating: 5,
    quote: 'We booked the café for our daughter\'s birthday lunch and every detail was looked after. The spring rolls and Phở were a huge hit, and the chè ba màu dessert had everyone asking for the recipe. Perfect afternoon.',
    date: 'April 2026',
    occasion: 'Private hire',
  },
  {
    id: '7',
    name: 'Oliver Greene',
    location: 'Ashford',
    rating: 5,
    quote: 'The lemongrass chicken bánh mì is the best sandwich I\'ve eaten in Kent. Full stop. The bread is perfectly crispy, the pickled vegetables are spot on, and every bite has something interesting happening.',
    date: 'February 2026',
    occasion: 'Lunch',
  },
  {
    id: '8',
    name: 'Yuki Tanaka',
    location: 'London',
    rating: 5,
    quote: 'I visited on a recommendation and immediately understood the hype. The matcha iced coffee is stunning, the bún bò Huế is deeply flavourful, and the bánh flan with drip coffee was a revelation. I\'ll be back soon.',
    date: 'March 2026',
    occasion: 'Weekend brunch',
  },
  {
    id: '9',
    name: 'Rachel & Kwame Osei',
    location: 'Ashford',
    rating: 5,
    quote: 'Our team lunch here was one of the best decisions we\'ve made. The menu caters beautifully for everyone — vegetarians loved the tofu bánh mì, the meat eaters were obsessed with the char siu pork. Genuinely excellent food.',
    date: 'May 2026',
    occasion: 'Corporate lunch',
  },
  {
    id: '10',
    name: 'Chloe Mitchell',
    location: 'Hythe',
    rating: 5,
    quote: 'The Phở broth is the most comforting thing I\'ve eaten this year. You can taste the hours that went into it. Plus the avocado coffee smoothie is dangerously good — I had two.',
    date: 'April 2026',
    occasion: 'Regular visit',
  },
]

export default testimonials
