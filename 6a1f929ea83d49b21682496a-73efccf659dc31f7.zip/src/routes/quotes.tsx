import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect } from 'react'

export const Route = createFileRoute('/quotes')({
  component: QuotesPage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

function StarRating({ rating, interactive = false, onRate }: { rating: number; interactive?: boolean; onRate?: (n: number) => void }) {
  const [hover, setHover] = useState(0)
  return (
    <div style={{ display: 'flex', gap: '4px' }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type={interactive ? 'button' : undefined}
          onClick={interactive && onRate ? () => onRate(i) : undefined}
          onMouseEnter={interactive ? () => setHover(i) : undefined}
          onMouseLeave={interactive ? () => setHover(0) : undefined}
          style={{
            background: 'none', border: 'none', padding: '1px',
            cursor: interactive ? 'pointer' : 'default',
            lineHeight: 1,
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24"
            fill={i <= (hover || rating) ? 'var(--gold)' : 'none'}
            stroke="var(--gold)" strokeWidth="2"
            style={{ transition: 'fill 0.15s' }}
          >
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </button>
      ))}
    </div>
  )
}

const aestheticQuotes = [
  { quote: 'Life is too short for bad coffee — and too beautiful not to savour every sip.', attr: null },
  { quote: "A good meal is not just food on a plate. It's warmth, memory, and belonging all at once.", attr: null },
  { quote: 'Every morning is a fresh start. So is every cup.', attr: null },
  { quote: 'The secret ingredient is always the people who made it with love.', attr: null },
  { quote: 'Where good food gathers, good things happen.', attr: null },
  { quote: 'Happiness is a warm drink, a familiar face, and a table you can stay at a little longer.', attr: null },
]

// Coffee and cozy café atmosphere images from Unsplash
const coffeeImages = [
  {
    src: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&q=80',
    alt: 'Latte art coffee cup',
  },
  {
    src: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80',
    alt: 'Coffee cup on wooden table',
  },
  {
    src: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=800&q=80',
    alt: 'Coffee and book cozy vibe',
  },
  {
    src: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80',
    alt: 'Latte art in a café',
  },
  {
    src: 'https://images.unsplash.com/photo-1481833761820-0509d3217039?w=800&q=80',
    alt: 'Cozy café window seat',
  },
  {
    src: 'https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=800&q=80',
    alt: 'Café interior atmosphere',
  },
]

interface Review {
  id: number
  name: string
  location: string
  occasion: string
  rating: number
  quote: string
  createdAt: string
}

function ReviewCard({ review, index, onDelete }: { review: Review; index: number; onDelete?: (id: number) => void }) {
  const bg = index % 3 === 0 ? 'var(--bark)' : index % 3 === 1 ? '#fff' : 'var(--ink)'
  const textColor = index % 3 === 1 ? 'var(--bark)' : 'var(--parchment)'
  const subColor = index % 3 === 1 ? 'var(--ash)' : 'rgba(255,255,255,0.5)'

  return (
    <div style={{
      background: bg,
      border: `1px solid ${index % 3 === 1 ? 'var(--smoke)' : 'transparent'}`,
      borderRadius: '6px',
      padding: '2rem',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      gap: '0.75rem',
    }}>
      {onDelete && (
        <button
          onClick={() => onDelete(review.id)}
          title="Delete review"
          style={{
            position: 'absolute',
            top: '1rem',
            right: '1rem',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '4px',
            borderRadius: '4px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: index % 3 === 1 ? 'rgba(196,98,45,0.6)' : 'rgba(255,255,255,0.4)',
            transition: 'color 0.2s, background-color 0.2s',
            zIndex: 2,
          }}
          onMouseEnter={e => {
            e.currentTarget.style.color = 'var(--ember)'
            e.currentTarget.style.backgroundColor = index % 3 === 1 ? 'rgba(196,98,45,0.1)' : 'rgba(255,255,255,0.1)'
          }}
          onMouseLeave={e => {
            e.currentTarget.style.color = index % 3 === 1 ? 'rgba(196,98,45,0.6)' : 'rgba(255,255,255,0.4)'
            e.currentTarget.style.backgroundColor = 'transparent'
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            <line x1="10" y1="11" x2="10" y2="17"></line>
            <line x1="14" y1="11" x2="14" y2="17"></line>
          </svg>
        </button>
      )}
      <div style={{
        position: 'absolute', top: '1.25rem', left: '1.75rem',
        fontFamily: "'Cormorant Garamond', serif",
        fontSize: '5rem', lineHeight: 0.5,
        color: 'var(--ember)', opacity: 0.2, pointerEvents: 'none',
      }}>"</div>
      <div style={{ position: 'relative', zIndex: 1 }}>
        <StarRating rating={review.rating} />
      </div>
      <blockquote style={{
        fontFamily: "'Cormorant Garamond', serif",
        fontSize: '1.1rem',
        fontStyle: 'italic',
        color: textColor,
        lineHeight: 1.7,
        margin: 0,
        position: 'relative',
        zIndex: 1,
      }}>
        {review.quote}
      </blockquote>
      <div style={{ width: '28px', height: '2px', background: 'var(--ember)' }} />
      <div style={{ zIndex: 1 }}>
        <div style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontSize: '1rem',
          fontWeight: 500,
          color: textColor,
        }}>{review.name}</div>
        {(review.location || review.occasion) && (
          <div style={{ fontSize: '0.75rem', color: subColor, marginTop: '0.2rem' }}>
            {[review.location, review.occasion].filter(Boolean).join(' · ')}
          </div>
        )}
      </div>
    </div>
  )
}

function QuotesPage() {
  const [fields, setFields] = useState({ name: '', location: '', occasion: '', rating: '5', quote: '' })
  const [rating, setRating] = useState(5)
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [reviews, setReviews] = useState<Review[]>([])
  const [pendingReview, setPendingReview] = useState<Review | null>(null)
  const [loadingReviews, setLoadingReviews] = useState(true)

  useEffect(() => {
    fetch('/api/reviews')
      .then(r => r.json())
      .then(setReviews)
      .catch(() => setReviews([]))
      .finally(() => setLoadingReviews(false))
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
  }

  const handleDelete = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this review?")) {
      return
    }

    try {
      const res = await fetch(`/api/reviews?id=${id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        setReviews(prev => prev.filter(r => r.id !== id))
        if (pendingReview?.id === id) {
          setPendingReview(null)
        }
      } else {
        alert("Failed to delete review")
      }
    } catch {
      alert("Error deleting review")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    // Save to Netlify Forms (for email notifications)
    fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'review', ...fields, rating: String(rating) }),
    }).catch(() => {})

    // Save to database so it shows on this page
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...fields, rating }),
      })
      if (res.ok) {
        const saved: Review = await res.json()
        setPendingReview(saved)
        setReviews(prev => [saved, ...prev])
      }
    } catch {}

    setSubmitting(false)
    setSubmitted(true)
  }

  const allReviews = reviews

  return (
    <>
      {/* Header with coffee image */}
      <div style={{
        background: 'var(--bark)',
        padding: '5rem 2.5rem 4rem',
        position: 'relative',
        overflow: 'hidden',
        minHeight: '380px',
        display: 'flex',
        alignItems: 'center',
      }}>
        <img
          src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1200&q=75"
          alt="Coffee with latte art"
          style={{
            position: 'absolute', inset: 0,
            width: '100%', height: '100%',
            objectFit: 'cover', objectPosition: 'center',
            opacity: 0.18,
          }}
        />
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 60% 60%, rgba(200,148,58,0.1) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>Good vibes only</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            A Little Warmth
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '480px', lineHeight: 1.8 }}>
            Words to savour alongside your coffee. And if you've visited us, we'd love to hear yours.
          </p>
        </div>
      </div>

      {/* Coffee Photo Mosaic */}
      <section style={{ background: 'var(--ink)', padding: '3rem 0' }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(6, 1fr)',
            gridTemplateRows: '200px',
            gap: '0.5rem',
            borderRadius: '8px',
            overflow: 'hidden',
          }}>
            {coffeeImages.map((img, i) => (
              <div key={i} style={{
                position: 'relative',
                overflow: 'hidden',
                gridColumn: i === 0 ? 'span 2' : 'span 1',
              }}>
                <img
                  src={img.src}
                  alt={img.alt}
                  style={{
                    width: '100%', height: '100%',
                    objectFit: 'cover',
                    transition: 'transform 0.4s ease',
                    display: 'block',
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1.07)' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLImageElement).style.transform = '' }}
                />
                <div style={{
                  position: 'absolute', inset: 0,
                  background: 'linear-gradient(to top, rgba(26,18,8,0.45) 0%, transparent 50%)',
                }} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Aesthetic Quotes Grid */}
      <section className="section" style={{ background: 'var(--parchment)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <div className="label">Words to live by</div>
            <h2 className="heading-xl">Café Philosophy</h2>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '1.5rem',
            marginBottom: '5rem',
          }}>
            {aestheticQuotes.map((q, i) => (
              <div key={i} style={{
                background: i % 3 === 0 ? 'var(--bark)' : i % 3 === 1 ? '#fff' : 'var(--ink)',
                border: `1px solid ${i % 3 === 1 ? 'var(--smoke)' : 'transparent'}`,
                borderRadius: '6px',
                padding: '2.5rem 2rem',
                position: 'relative',
                overflow: 'hidden',
                minHeight: '180px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
                <div style={{
                  position: 'absolute', top: '1.25rem', left: '1.75rem',
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '5rem', lineHeight: 0.5,
                  color: 'var(--ember)', opacity: 0.25, pointerEvents: 'none',
                }}>"</div>
                <blockquote style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '1.2rem', fontStyle: 'italic',
                  color: i % 3 === 1 ? 'var(--bark)' : 'var(--parchment)',
                  lineHeight: 1.7, margin: 0, position: 'relative', zIndex: 1,
                }}>
                  {q.quote}
                </blockquote>
                <div style={{ marginTop: '1.25rem', width: '32px', height: '2px', background: 'var(--ember)' }} />
              </div>
            ))}
          </div>

          {/* Customer Reviews Section */}
          {(allReviews.length > 0 || loadingReviews) && (
            <>
              <div style={{
                textAlign: 'center',
                padding: '3rem 0 2rem',
                borderTop: '1px solid var(--smoke)',
                marginBottom: '2.5rem',
              }}>
                <div className="label">From Our Guests</div>
                <h2 className="heading-xl">What People Are Saying</h2>
              </div>

              {loadingReviews ? (
                <div style={{ textAlign: 'center', color: 'var(--ash)', padding: '2rem 0', fontStyle: 'italic' }}>
                  Loading reviews…
                </div>
              ) : (
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                  gap: '1.5rem',
                  marginBottom: '4rem',
                }}>
                  {allReviews.map((review, i) => (
                    <ReviewCard key={review.id} review={review} index={i} onDelete={handleDelete} />
                  ))}
                </div>
              )}
            </>
          )}

          {/* Cozy coffee image break */}
          <div style={{
            borderRadius: '8px',
            overflow: 'hidden',
            marginBottom: '4rem',
            height: '260px',
            position: 'relative',
          }}>
            <img
              src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=1400&q=80"
              alt="Coffee and book in a cozy café"
              style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 60%' }}
            />
            <div style={{
              position: 'absolute', inset: 0,
              background: 'linear-gradient(90deg, rgba(26,18,8,0.65) 0%, rgba(26,18,8,0.1) 60%)',
              display: 'flex', alignItems: 'center', padding: '0 3rem',
            }}>
              <div>
                <div className="label" style={{ color: 'var(--gold)' }}>The simple things</div>
                <p style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: 'clamp(1.4rem, 3vw, 2rem)',
                  fontStyle: 'italic',
                  color: 'var(--parchment)',
                  maxWidth: '420px',
                  lineHeight: 1.4,
                  margin: '0.5rem 0 0',
                }}>
                  A good cup. A quiet corner. Time to breathe.
                </p>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div style={{
            textAlign: 'center',
            padding: '3rem 0',
            borderTop: '1px solid var(--smoke)',
            borderBottom: '1px solid var(--smoke)',
            marginBottom: '4rem',
          }}>
            <div className="label" style={{ marginBottom: '0.75rem' }}>Your Turn</div>
            <h2 className="heading-xl" style={{ marginBottom: '0.75rem' }}>Leave a Review</h2>
            <p style={{ color: 'var(--ash)', lineHeight: 1.8, maxWidth: '480px', margin: '0 auto', fontSize: '0.9rem' }}>
              We read every review personally. Your feedback helps us improve and helps other guests know what to expect.
              Submitted reviews appear on this page automatically.
            </p>
          </div>

          {/* Customer Review Form */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '5rem', alignItems: 'flex-start' }}>
            <div>
              <div className="label">Share Your Experience</div>
              <h2 className="heading-xl" style={{ marginBottom: '1.25rem' }}>Been to see us?</h2>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '1rem' }}>
                Whether it was your first visit or your hundredth, we'd genuinely love to hear about it — the good, and any way we can do better.
              </p>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, fontSize: '0.875rem' }}>
                Your review will appear on this page as soon as it's submitted.
              </p>
              <div style={{ marginTop: '2rem' }}>
                <img
                  src="https://images.unsplash.com/photo-1481833761820-0509d3217039?w=600&q=80"
                  alt="Cozy café window"
                  style={{ width: '100%', borderRadius: '6px', objectFit: 'cover', height: '220px' }}
                />
              </div>
            </div>

            <div style={{ background: 'var(--parchment)', border: '1px solid var(--smoke)', borderRadius: '6px', padding: '2.5rem' }}>
              {submitted ? (
                <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                  <div style={{
                    width: '52px', height: '52px', borderRadius: '50%',
                    background: 'rgba(196,98,45,0.1)', border: '2px solid var(--ember)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem',
                  }}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', marginBottom: '0.75rem' }}>
                    Thank you, {fields.name}.
                  </h3>
                  <p style={{ color: 'var(--ash)', lineHeight: 1.8 }}>
                    Your review has been received and is now live on this page. We're genuinely grateful for the time you took to write it.
                  </p>
                  {pendingReview && (
                    <div style={{
                      marginTop: '1.5rem',
                      padding: '1.5rem',
                      background: '#fff',
                      borderRadius: '6px',
                      border: '1px solid var(--smoke)',
                      textAlign: 'left',
                    }}>
                      <div style={{ marginBottom: '0.5rem' }}>
                        <StarRating rating={pendingReview.rating} />
                      </div>
                      <p style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontStyle: 'italic',
                        color: 'var(--bark)',
                        fontSize: '1rem',
                        lineHeight: 1.6,
                        margin: '0 0 0.75rem',
                      }}>"{pendingReview.quote}"</p>
                      <div style={{ fontSize: '0.8rem', color: 'var(--ash)' }}>— {pendingReview.name}</div>
                    </div>
                  )}
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <input type="hidden" name="form-name" value="review" />
                  <input type="text" name="bot-field" style={{ display: 'none' }} />

                  <div className="form-group">
                    <label className="form-label">Your Rating *</label>
                    <StarRating rating={rating} interactive onRate={setRating} />
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label className="form-label">Your Name *</label>
                      <input className="form-input" name="name" required value={fields.name} onChange={handleChange} placeholder="First name or full name" style={{ background: '#fff' }} />
                    </div>
                    <div>
                      <label className="form-label">Location</label>
                      <input className="form-input" name="location" value={fields.location} onChange={handleChange} placeholder="Town / city" style={{ background: '#fff' }} />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Occasion</label>
                    <select className="form-select" name="occasion" value={fields.occasion} onChange={handleChange} style={{ background: '#fff' }}>
                      <option value="">Select occasion</option>
                      <option value="Regular visit">Regular visit</option>
                      <option value="Weekend brunch">Weekend brunch</option>
                      <option value="Weekday visit">Weekday visit</option>
                      <option value="Lunch">Lunch</option>
                      <option value="Special occasion">Special occasion</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Your Review *</label>
                    <textarea
                      className="form-textarea"
                      name="quote"
                      required
                      rows={4}
                      value={fields.quote}
                      onChange={handleChange}
                      placeholder="Tell us about your experience…"
                      style={{ background: '#fff' }}
                    />
                  </div>

                  <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={submitting}>
                    {submitting ? 'Submitting…' : 'Submit Review'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
