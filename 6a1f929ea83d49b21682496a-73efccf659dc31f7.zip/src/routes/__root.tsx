import { createRootRoute, Outlet, HeadContent, Scripts, Link, useRouterState } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'KoKio Bếp — Café & Vietnamese Kitchen' },
      { name: 'description', content: 'Authentic Vietnamese café and kitchen. Vietnamese coffee, bánh mì, phở, and more. Dine in, take away, or hire us for your next event.' },
    ],
  }),
  shellComponent: RootDocument,
  component: RootLayout,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  )
}

function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const routerState = useRouterState()
  const currentPath = routerState.location.pathname

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
  }, [currentPath])

  const links = [
    { to: '/', label: 'Home' },
    { to: '/menu', label: 'Menu' },
    { to: '/order', label: 'Order' },
    { to: '/quotes', label: 'Reviews' },
    { to: '/careers', label: 'Careers' },
    { to: '/location', label: 'Find Us' },
    { to: '/contact', label: 'Contact' },
  ]

  return (
    <nav className={`nav${scrolled ? ' scrolled' : ''}${menuOpen ? ' menu-open' : ''}`}>
      <Link to="/" className="nav-logo">
        KoKio <span>Bếp</span>
      </Link>
      <ul className="nav-links">
        {links.map((link) => (
          <li key={link.to}>
            <Link to={link.to} className={currentPath === link.to ? 'active' : ''}>
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
      <Link to="/order" className="nav-reserve-btn" style={{ display: 'flex' }}>
        Order Now
      </Link>
      <button
        className="nav-mobile-toggle"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Toggle menu"
      >
        <span style={{ transform: menuOpen ? 'translateY(6.5px) rotate(45deg)' : '' }} />
        <span style={{ opacity: menuOpen ? 0 : 1 }} />
        <span style={{ transform: menuOpen ? 'translateY(-6.5px) rotate(-45deg)' : '' }} />
      </button>
    </nav>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div className="footer-brand">
          <h3>KoKio <span>Bếp</span></h3>
          <p>
            Authentic Vietnamese café and kitchen.
            Vietnamese coffee, bánh mì, phở, and seasonal dishes.
            Dine in or take away.
          </p>
        </div>
        <div className="footer-col">
          <h4>Explore</h4>
          <ul>
            <li><Link to="/menu">Our Menu</Link></li>
            <li><Link to="/order">Order Online</Link></li>
            <li><Link to="/quotes">Leave a Review</Link></li>
            <li><Link to="/careers">Careers</Link></li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Opening Hours</h4>
          <ul>
            <li>Monday: Closed</li>
            <li>Tue – Sat: 7am – 7pm</li>
            <li>Sunday: 8am – 6pm</li>
            <li style={{ marginTop: '0.75rem', opacity: 0.5 }}>Kitchen closes 30 min before</li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Get in Touch</h4>
          <ul>
            <li>KoKio Bếp</li>
            <li>Ashford, Kent</li>
            <li style={{ marginTop: '0.75rem' }}>
              <a href="tel:+441234567890">+44 1234 567 890</a>
            </li>
            <li>
              <a href="mailto:hello@kokiobep.co.uk">hello@kokiobep.co.uk</a>
            </li>
          </ul>
        </div>
      </div>
      <hr className="footer-divider" />
      <div className="footer-bottom">
        <span>© 2026 KoKio Bếp. All rights reserved.</span>
        <span>Ashford, Kent</span>
      </div>
    </footer>
  )
}

function RootLayout() {
  return (
    <>
      <Nav />
      <main>
        <Outlet />
      </main>
      <Footer />
    </>
  )
}
