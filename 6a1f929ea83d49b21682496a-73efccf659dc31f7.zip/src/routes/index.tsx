import { createFileRoute, Link } from '@tanstack/react-router'
import menuItems from '@/data/menu'

export const Route = createFileRoute('/')({
  component: HomePage,
})

const featuredItems = menuItems.filter((m) => m.popular).slice(0, 4)

// Cozy coffee atmosphere images for the hero mosaic
const heroImages = [
  {
    src: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=80',
    alt: 'Vietnamese latte art',
    label: 'Vietnamese Coffee',
  },
  {
    src: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80',
    alt: 'Coffee cup on wooden table',
    label: 'Bánh Mì Fresh Daily',
  },
  {
    src: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=600&q=80',
    alt: 'Coffee beans close up',
    label: 'Fresh Kitchen Daily',
  },
  {
    src: 'https://images.unsplash.com/photo-1481833761820-0509d3217039?w=600&q=80',
    alt: 'Cozy café window',
    label: 'Ashford, Kent',
  },
]

const aestheticQuotes = [
  { quote: 'Life is too short for bad coffee — and too beautiful not to savour every sip.', icon: '☕' },
  { quote: 'Every morning is a fresh start. So is every cup.', icon: '🌅' },
  { quote: 'Where good food gathers, good things happen.', icon: '🫶' },
]

const galleryPhotos = [
  {
    label: 'Egg Coffee',
    sublabel: 'Cà Phê Trứng',
    src: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=900&q=80',
    alt: 'Coffee with latte art',
    accent: 'hsl(45,70%,70%)',
  },
  {
    label: 'Bánh Mì',
    sublabel: 'Fresh Baguette',
    src: 'https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=600&q=80',
    alt: 'Café interior',
    accent: 'hsl(40,80%,80%)',
  },
  {
    label: 'Phở Bò',
    sublabel: '12-Hour Broth',
    src: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=600&q=80',
    alt: 'Coffee beans',
    accent: 'hsl(30,60%,75%)',
  },
  {
    label: 'Coconut Coffee',
    sublabel: 'Cà Phê Dừa',
    src: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=600&q=80',
    alt: 'Coffee and book cozy',
    accent: 'hsl(60,50%,80%)',
  },
  {
    label: 'Chả Giò',
    sublabel: 'Spring Rolls',
    src: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80',
    alt: 'Coffee cup on table',
    accent: 'hsl(35,75%,75%)',
  },
  {
    label: 'Chè Ba Màu',
    sublabel: 'Three-Colour Dessert',
    src: 'https://images.unsplash.com/photo-1481833761820-0509d3217039?w=600&q=80',
    alt: 'Cozy café window',
    accent: 'hsl(320,45%,80%)',
  },
]

function HomePage() {
  return (
    <>
      {/* ── Hero ─────────────────────────────────────── */}
      <section style={{
        minHeight: '100vh',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Left panel */}
        <div style={{
          background: 'var(--bark)',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          padding: '8rem 5rem 6rem',
          position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(196,98,45,0.18) 0%, transparent 60%), radial-gradient(circle at 80% 20%, rgba(200,148,58,0.10) 0%, transparent 50%)',
          }} />
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>
              Café & Vietnamese Kitchen · Ashford, Kent
            </div>
            <h1 className="animate-fade-up delay-100" style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: 'clamp(3rem, 7vw, 5.5rem)',
              fontWeight: 500,
              lineHeight: 1.05,
              color: 'var(--parchment)',
              marginBottom: '1.75rem',
            }}>
              KoKio<br />
              <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Bếp</span>
            </h1>
            <p className="animate-fade-up delay-200" style={{
              color: 'var(--smoke)',
              fontSize: '1rem',
              maxWidth: '380px',
              lineHeight: 1.8,
              marginBottom: '2.5rem',
              fontWeight: 300,
            }}>
              Authentic Vietnamese coffee, bánh mì, and home-style kitchen cooking.
              Open Tuesday to Sunday — dine in or take away.
            </p>
            <div className="animate-fade-up delay-300" style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <Link to="/menu" className="btn-primary">See the Menu</Link>
              <Link to="/order" className="btn-ghost" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'var(--parchment)' }}>
                Order Online
              </Link>
            </div>
            <div className="animate-fade-up delay-400" style={{
              marginTop: '3.5rem',
              paddingTop: '2rem',
              borderTop: '1px solid rgba(255,255,255,0.1)',
              display: 'flex',
              gap: '2.5rem',
            }}>
              {[['10+', 'Coffee drinks'], ['4.9★', 'Rated'], ['Daily', 'Fresh Kitchen']].map(([val, label]) => (
                <div key={label}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--gold)', lineHeight: 1 }}>{val}</div>
                  <div style={{ fontSize: '0.7rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--ash)', marginTop: '0.35rem' }}>{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right panel — photo mosaic */}
        <div style={{ position: 'relative', background: 'var(--ink)', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 0, display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '1fr 1fr', gap: '3px' }}>
            {heroImages.map((cell, i) => (
              <div key={i} style={{ position: 'relative', overflow: 'hidden' }}>
                <img
                  src={cell.src}
                  alt={cell.alt}
                  style={{
                    width: '100%', height: '100%',
                    objectFit: 'cover',
                    transition: 'transform 0.5s ease',
                    display: 'block',
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLImageElement).style.transform = 'scale(1.06)' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLImageElement).style.transform = '' }}
                />
                <div style={{
                  position: 'absolute', inset: 0,
                  background: 'linear-gradient(to top, rgba(26,18,8,0.6) 0%, transparent 55%)',
                  display: 'flex',
                  alignItems: 'flex-end',
                  padding: '0.85rem 1rem',
                }}>
                  <span style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontSize: '0.95rem',
                    color: 'var(--parchment)',
                    fontWeight: 500,
                    letterSpacing: '0.03em',
                  }}>{cell.label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <style>{`
          @media (max-width: 768px) {
            .hero-grid { grid-template-columns: 1fr !important; }
            .hero-grid > div:last-child { display: none !important; }
            .hero-grid > div:first-child { padding: 5rem 2rem 4rem !important; }
          }
        `}</style>
      </section>

      {/* ── Intro Strip ──────────────────────────────── */}
      <section style={{
        background: 'var(--ember)',
        padding: '1.5rem 2.5rem',
        overflow: 'hidden',
      }}>
        <div style={{
          display: 'flex',
          gap: '4rem',
          justifyContent: 'center',
          flexWrap: 'wrap',
          alignItems: 'center',
        }}>
          {[
            'Vietnamese Coffee',
            '·',
            'Bánh Mì & Phở',
            '·',
            'Fresh Kitchen Daily',
            '·',
            'Ashford, Kent',
          ].map((item, i) => (
            <span key={i} style={{
              color: '#fff',
              fontSize: item === '·' ? '1.5rem' : '0.75rem',
              fontWeight: item === '·' ? 300 : 500,
              letterSpacing: item === '·' ? 0 : '0.15em',
              textTransform: 'uppercase',
              opacity: item === '·' ? 0.5 : 1,
            }}>{item}</span>
          ))}
        </div>
      </section>

      {/* ── About / Philosophy ───────────────────────── */}
      <section className="section">
        <div className="container" style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '6rem', alignItems: 'center' }}>
          <div>
            <div className="label">Our Story</div>
            <h2 className="heading-xl" style={{ marginBottom: '1.5rem' }}>
              Vietnamese<br />
              flavours, made<br />
              <em style={{ fontStyle: 'italic', color: 'var(--ember)' }}>with heart.</em>
            </h2>
            <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '1.5rem', maxWidth: '400px' }}>
              KoKio Bếp is a Vietnamese café and kitchen in Ashford, Kent. We bring the recipes, techniques, and warmth of Vietnamese home cooking to a relaxed café setting.
            </p>
            <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '2rem', maxWidth: '400px' }}>
              From egg coffee and coconut coffee to bánh mì and bowls of steaming phở — everything is made fresh, made properly, and made with pride.
            </p>
            <Link to="/menu" className="btn-outline">See the Full Menu</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
            {[
              { title: 'Vietnamese Coffee', desc: 'Egg coffee, coconut coffee, salted coffee, avocado coffee, and more. All the Vietnamese classics plus western espresso drinks.' },
              { title: 'Fresh Kitchen Daily', desc: 'Bánh mì, phở, bún bò Huế, spring rolls, and fried rice — made fresh each day in our kitchen.' },
              { title: 'Join Our Team', desc: 'We\'re hiring baristas, kitchen staff, and café runners. Come work somewhere you\'ll be proud of. See our Careers page for open roles.' },
              { title: 'Authentic Recipes', desc: 'Every recipe is rooted in Vietnamese culinary tradition, adapted with care for the freshest local ingredients.' },
            ].map((item, i) => (
              <div key={i} style={{
                background: i % 2 === 0 ? 'var(--parchment)' : '#fff',
                border: '1px solid var(--smoke)',
                borderRadius: '4px',
                padding: '1.75rem',
                transition: 'transform 0.2s, box-shadow 0.2s',
              }}
                onMouseEnter={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)'
                  ;(e.currentTarget as HTMLElement).style.boxShadow = '0 12px 40px rgba(58,37,16,0.1)'
                }}
                onMouseLeave={e => {
                  ;(e.currentTarget as HTMLElement).style.transform = ''
                  ;(e.currentTarget as HTMLElement).style.boxShadow = ''
                }}
              >
                <div style={{
                  width: '28px', height: '2px',
                  background: 'var(--ember)',
                  marginBottom: '1rem',
                }} />
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.2rem', marginBottom: '0.5rem', color: 'var(--bark)' }}>{item.title}</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--ash)', lineHeight: 1.7, margin: 0 }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Photo Gallery ────────────────────────────── */}
      <section className="section" style={{ background: 'var(--ink)', paddingTop: '5rem', paddingBottom: '5rem' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <div className="label" style={{ color: 'var(--gold)' }}>From Our Kitchen</div>
            <h2 className="heading-xl" style={{ color: 'var(--parchment)', marginBottom: '0.5rem' }}>Food & Drinks</h2>
            <p style={{ color: 'var(--smoke)', maxWidth: '480px', margin: '0 auto', lineHeight: 1.7, fontSize: '0.9rem' }}>
              Made fresh every day — from our Vietnamese coffees to our slow-cooked phở broth.
            </p>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gridTemplateRows: 'repeat(2, 220px)',
            gap: '0.75rem',
          }}>
            {galleryPhotos.map((photo, i) => (
              <div key={i} style={{
                borderRadius: '6px',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
                gridColumn: i === 0 ? 'span 2' : 'span 1',
                transition: 'transform 0.2s',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'scale(1.01)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = '' }}
              >
                <img
                  src={photo.src}
                  alt={photo.alt}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                />
                <div style={{
                  position: 'absolute', inset: 0,
                  background: 'linear-gradient(to top, rgba(26,18,8,0.75) 0%, rgba(26,18,8,0.15) 60%, transparent 100%)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'flex-end',
                  padding: i === 0 ? '1.5rem 2rem' : '1rem 1.25rem',
                }}>
                  <div style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontSize: i === 0 ? '1.6rem' : '1.1rem',
                    color: photo.accent,
                    fontWeight: 500,
                    lineHeight: 1.2,
                  }}>{photo.label}</div>
                  <div style={{ fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.5)', marginTop: '0.25rem' }}>
                    {photo.sublabel}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
            <Link to="/menu" className="btn-ghost" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'var(--parchment)' }}>
              View Full Menu
            </Link>
          </div>
        </div>
        <style>{`
          @media (max-width: 768px) {
            .gallery-grid { grid-template-columns: 1fr 1fr !important; }
          }
          @media (max-width: 500px) {
            .gallery-grid { grid-template-columns: 1fr !important; }
          }
        `}</style>
      </section>

      {/* ── Featured Menu ────────────────────────────── */}
      <section className="section" style={{ background: 'var(--parchment)' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '3rem', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <div className="label">From the Kitchen</div>
              <h2 className="heading-xl">Popular dishes</h2>
            </div>
            <Link to="/menu" style={{ fontSize: '0.8rem', fontWeight: 500, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--ember)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              View full menu
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem' }}>
            {featuredItems.map((item, i) => {
              const cardGradients = [
                'linear-gradient(135deg, hsl(30,55%,30%), hsl(25,45%,22%))',
                'linear-gradient(135deg, hsl(20,60%,38%), hsl(15,50%,28%))',
                'linear-gradient(135deg, hsl(80,35%,30%), hsl(85,28%,22%))',
                'linear-gradient(135deg, hsl(290,25%,30%), hsl(300,20%,22%))',
              ]
              const cardIcons = ['☕', '🥖', '🍜', '🥥']
              return (
                <div key={item.id} className="card" style={{ animationDelay: `${i * 0.1}s` }}>
                  <div style={{
                    height: '180px',
                    background: cardGradients[i] || cardGradients[0],
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.5rem',
                    position: 'relative',
                  }}>
                    <span style={{ fontSize: '3rem' }}>{cardIcons[i] || '🍽️'}</span>
                    <div style={{ position: 'absolute', top: '0.75rem', right: '0.75rem' }}>
                      <span className="badge badge-ember">Popular</span>
                    </div>
                  </div>
                  <div style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                      <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.2rem', color: 'var(--bark)' }}>{item.name}</h3>
                      <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', color: 'var(--ember)', fontWeight: 600, whiteSpace: 'nowrap', marginLeft: '0.5rem' }}>£{item.price.toFixed(2)}</span>
                    </div>
                    <p style={{ fontSize: '0.83rem', color: 'var(--ash)', lineHeight: 1.6, margin: 0 }}>{item.description}</p>
                    <div style={{ marginTop: '1rem', display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
                      {item.vegan && <span className="badge">Vegan</span>}
                      {item.vegetarian && !item.vegan && <span className="badge">Vegetarian</span>}
                      {item.glutenFree && <span className="badge">GF</span>}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div style={{ textAlign: 'center', marginTop: '3rem' }}>
            <Link to="/order" className="btn-primary">Order Now</Link>
          </div>
        </div>
      </section>

      {/* ── Coffee Ambience Strip ────────────────────── */}
      <section style={{ overflow: 'hidden', height: '320px', position: 'relative' }}>
        <div style={{ display: 'flex', height: '100%' }}>
          {[
            { src: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=75', alt: 'Latte art' },
            { src: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=75', alt: 'Coffee on table' },
            { src: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=600&q=75', alt: 'Coffee and book' },
            { src: 'https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=600&q=75', alt: 'Café interior' },
          ].map((img, i) => (
            <div key={i} style={{ flex: i === 1 ? 1.5 : 1, position: 'relative', overflow: 'hidden' }}>
              <img
                src={img.src}
                alt={img.alt}
                style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
              />
              <div style={{ position: 'absolute', inset: 0, background: 'rgba(26,18,8,0.25)' }} />
            </div>
          ))}
        </div>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(90deg, rgba(26,18,8,0.4) 0%, transparent 30%, transparent 70%, rgba(26,18,8,0.4) 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          pointerEvents: 'none',
        }}>
          <p style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 'clamp(1.5rem, 4vw, 2.5rem)',
            fontStyle: 'italic',
            color: 'var(--parchment)',
            textAlign: 'center',
            textShadow: '0 2px 20px rgba(0,0,0,0.5)',
            maxWidth: '600px',
            padding: '0 2rem',
            lineHeight: 1.3,
          }}>
            "Every cup tells a story.<br />Come in and write yours."
          </p>
        </div>
      </section>

      {/* ── Aesthetic Quotes Strip ───────────────────── */}
      <section style={{ background: 'var(--bark)', padding: '5rem 2.5rem' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <div className="label" style={{ color: 'var(--gold)' }}>Good vibes only</div>
            <h2 className="heading-xl" style={{ color: 'var(--parchment)', marginBottom: '0.5rem' }}>A little warmth</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', marginBottom: '3rem' }}>
            {aestheticQuotes.map((q, i) => (
              <div key={i} style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '6px',
                padding: '2.5rem 2rem',
                position: 'relative',
                overflow: 'hidden',
              }}>
                <div style={{
                  position: 'absolute', top: '1.25rem', left: '1.75rem',
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '4rem', lineHeight: 0.5,
                  color: 'var(--ember)', opacity: 0.3, pointerEvents: 'none',
                }}>"</div>
                <div style={{ fontSize: '1.75rem', marginBottom: '1rem', position: 'relative', zIndex: 1 }}>{q.icon}</div>
                <blockquote style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '1.1rem',
                  fontStyle: 'italic',
                  color: 'var(--parchment)',
                  lineHeight: 1.7,
                  margin: '0 0 1.25rem',
                  position: 'relative',
                  zIndex: 1,
                }}>
                  {q.quote}
                </blockquote>
                <div style={{ width: '28px', height: '2px', background: 'var(--ember)' }} />
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center' }}>
            <Link to="/quotes" className="btn-ghost" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'var(--parchment)' }}>
              Leave a Review
            </Link>
          </div>
        </div>
      </section>

      {/* ── Careers CTA ──────────────────────────────── */}
      <section className="section">
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '0',
            border: '1px solid var(--smoke)',
            borderRadius: '6px',
            overflow: 'hidden',
          }}>
            <div style={{ padding: '4rem', background: 'var(--parchment)' }}>
              <div className="label">Join the Team</div>
              <h2 className="heading-xl" style={{ marginBottom: '1.25rem' }}>
                Work with us.
              </h2>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '0.75rem' }}>
                We're growing and looking for warm, passionate people to join our team in Ashford. Whether you love coffee, food, or people — there's a place for you here.
              </p>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '2rem' }}>
                Full training provided. A genuinely great team to be part of.
              </p>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <Link to="/careers" className="btn-primary">See Open Roles</Link>
                <Link to="/careers" className="btn-outline">Apply Now</Link>
              </div>
            </div>
            <div style={{
              background: 'var(--oak)',
              padding: '4rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', inset: 0,
                background: 'radial-gradient(circle at 70% 30%, rgba(200,148,58,0.2) 0%, transparent 60%)',
              }} />
              <div style={{ position: 'relative', zIndex: 1 }}>
                {[
                  ['Barista', 'Now hiring'],
                  ['Kitchen Staff', 'Now hiring'],
                  ['Café Runner', 'Now hiring'],
                  ['Training', 'Fully provided'],
                ].map(([val, label]) => (
                  <div key={val} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '1rem 0',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                  }}>
                    <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.5rem', color: 'var(--gold)' }}>{val}</span>
                    <span style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.6)', alignSelf: 'center' }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Opening Hours & Location ─────────────────── */}
      <section className="section-sm" style={{ background: 'var(--ink)' }}>
        <div className="container" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem' }}>
          <div>
            <div className="label" style={{ color: 'var(--gold)' }}>Opening Hours</div>
            <div style={{ marginTop: '1rem' }}>
              {[
                ['Monday', 'Closed'],
                ['Tuesday – Saturday', '7:00 am – 7:00 pm'],
                ['Sunday', '8:00 am – 6:00 pm'],
              ].map(([day, hours]) => (
                <div key={day} style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '0.85rem 0',
                  borderBottom: '1px solid rgba(255,255,255,0.07)',
                  color: 'var(--smoke)',
                  fontSize: '0.9rem',
                }}>
                  <span>{day}</span>
                  <span style={{ color: hours === 'Closed' ? 'var(--ash)' : 'var(--parchment)' }}>{hours}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="label" style={{ color: 'var(--gold)' }}>Find Us</div>
            <p style={{ color: 'var(--smoke)', lineHeight: 1.8, marginTop: '1rem', marginBottom: '1.5rem' }}>
              KoKio Bếp<br />
              Ashford, Kent
            </p>
            <p style={{ color: 'var(--ash)', fontSize: '0.875rem', marginBottom: '1.5rem' }}>
              Easy to find in the heart of Ashford. Come hungry — there is always something delicious waiting.
            </p>
            <Link to="/location" className="btn-ghost" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'var(--parchment)' }}>
              Get Directions
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
