import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'
import menuItems, { menuCategories, type MenuItem } from '@/data/menu'

export const Route = createFileRoute('/order')({
  component: OrderPage,
})

interface CartItem extends MenuItem {
  qty: number
}

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

function OrderPage() {
  const [activeCategory, setActiveCategory] = useState('coffee')
  const [cart, setCart] = useState<CartItem[]>([])
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [notes, setNotes] = useState('')
  const [pickupTime, setPickupTime] = useState('')
  const [cardHolder, setCardHolder] = useState('')
  const [cardNumber, setCardNumber] = useState('')
  const [cardExpiry, setCardExpiry] = useState('')
  const [cardCvv, setCardCvv] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const filtered = menuItems.filter((m) => m.category === activeCategory)
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0)
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0)

  const addItem = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === item.id)
      if (existing) return prev.map((c) => c.id === item.id ? { ...c, qty: c.qty + 1 } : c)
      return [...prev, { ...item, qty: 1 }]
    })
  }

  const removeItem = (id: string) => {
    setCart((prev) => prev.map((c) => c.id === id ? { ...c, qty: c.qty - 1 } : c).filter((c) => c.qty > 0))
  }

  const getQty = (id: string) => cart.find((c) => c.id === id)?.qty ?? 0

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (cart.length === 0) return
    setSubmitting(true)
    const orderSummary = cart.map((c) => `${c.qty}× ${c.name} (£${(c.price * c.qty).toFixed(2)})`).join(', ')
    await fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({
        'form-name': 'order',
        name,
        email,
        'pickup-time': pickupTime,
        'order-summary': orderSummary,
        'order-total': `£${total.toFixed(2)}`,
        'card-holder': cardHolder,
        'card-last-four': cardNumber.replace(/\s/g, '').slice(-4),
        notes,
      }),
    })
    setSubmitting(false)
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
        <div style={{ textAlign: 'center', maxWidth: '480px' }}>
          <div style={{
            width: '64px', height: '64px', borderRadius: '50%',
            background: 'rgba(196,98,45,0.1)',
            border: '2px solid var(--ember)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 2rem',
          }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '2.5rem', color: 'var(--bark)', marginBottom: '1rem' }}>
            Order received.
          </h2>
          <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '0.75rem' }}>
            Thank you, {name}. We've received your order and will have it ready for {pickupTime || 'your chosen time'}.
          </p>
          <p style={{ color: 'var(--ash)', fontSize: '0.875rem', marginBottom: '2rem' }}>
            A confirmation will be sent to <strong>{email}</strong>.
          </p>
          <p style={{ color: 'var(--oak)', fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', marginBottom: '2rem' }}>
            Order total: £{total.toFixed(2)}
          </p>
          <Link to="/" className="btn-primary">Back to Home</Link>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Page Header */}
      <div style={{ background: 'var(--bark)', padding: '5rem 2.5rem 4rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 30% 60%, rgba(200,148,58,0.12) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>Click & Collect</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            Order Online
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '480px', lineHeight: 1.8 }}>
            Build your order below and collect from us at a time that suits you.
            Orders should be placed at least 30 minutes in advance.
          </p>
        </div>
      </div>

      <section className="section" style={{ paddingTop: '3rem' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '3rem', alignItems: 'flex-start' }}>

            {/* Left: menu browser */}
            <div>
              {/* Category tabs */}
              <div style={{
                display: 'flex',
                gap: '0.5rem',
                flexWrap: 'wrap',
                marginBottom: '2rem',
              }}>
                {menuCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    style={{
                      background: activeCategory === cat.id ? 'var(--ember)' : 'var(--parchment)',
                      color: activeCategory === cat.id ? '#fff' : 'var(--oak)',
                      border: activeCategory === cat.id ? '1px solid var(--ember)' : '1px solid var(--smoke)',
                      padding: '0.5rem 1.1rem',
                      borderRadius: '2px',
                      fontSize: '0.78rem',
                      fontWeight: 500,
                      letterSpacing: '0.08em',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Item grid */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1px', background: 'var(--smoke)', border: '1px solid var(--smoke)', borderRadius: '6px', overflow: 'hidden' }}>
                {filtered.map((item) => {
                  const qty = getQty(item.id)
                  return (
                    <div
                      key={item.id}
                      style={{
                        background: qty > 0 ? 'rgba(196,98,45,0.03)' : '#fff',
                        padding: '1.25rem 1.5rem',
                        display: 'flex',
                        gap: '1rem',
                        alignItems: 'center',
                        transition: 'background 0.15s',
                      }}
                    >
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
                          <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', color: 'var(--bark)', lineHeight: 1.2, margin: 0 }}>{item.name}</h3>
                          {item.popular && <span className="badge badge-ember">Popular</span>}
                        </div>
                        <p style={{ margin: '0.3rem 0 0', fontSize: '0.8rem', color: 'var(--ash)', lineHeight: 1.55 }}>{item.description}</p>
                        <div style={{ display: 'flex', gap: '0.35rem', marginTop: '0.4rem' }}>
                          {item.vegan && <span className="badge">Vegan</span>}
                          {item.vegetarian && !item.vegan && <span className="badge">Veg</span>}
                          {item.glutenFree && <span className="badge">GF</span>}
                        </div>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.5rem', minWidth: '100px' }}>
                        <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', color: 'var(--ember)', fontWeight: 600 }}>
                          £{item.price.toFixed(2)}
                        </span>
                        {qty === 0 ? (
                          <button
                            onClick={() => addItem(item)}
                            style={{
                              background: 'var(--ember)',
                              color: '#fff',
                              border: 'none',
                              borderRadius: '2px',
                              padding: '0.4rem 0.9rem',
                              fontSize: '0.75rem',
                              fontWeight: 500,
                              letterSpacing: '0.08em',
                              cursor: 'pointer',
                              transition: 'background 0.2s',
                            }}
                          >Add</button>
                        ) : (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <button
                              onClick={() => removeItem(item.id)}
                              style={{
                                width: '28px', height: '28px',
                                background: 'var(--parchment)',
                                border: '1px solid var(--smoke)',
                                borderRadius: '2px',
                                cursor: 'pointer',
                                fontSize: '1rem',
                                lineHeight: '1',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                color: 'var(--oak)',
                              }}
                            >−</button>
                            <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', fontWeight: 600, color: 'var(--bark)', minWidth: '16px', textAlign: 'center' }}>{qty}</span>
                            <button
                              onClick={() => addItem(item)}
                              style={{
                                width: '28px', height: '28px',
                                background: 'var(--ember)',
                                border: 'none',
                                borderRadius: '2px',
                                cursor: 'pointer',
                                fontSize: '1rem',
                                lineHeight: '1',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                color: '#fff',
                              }}
                            >+</button>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Right: Cart */}
            <div style={{
              position: 'sticky',
              top: 'calc(var(--nav-height) + 1.5rem)',
              background: '#fff',
              border: '1px solid var(--smoke)',
              borderRadius: '6px',
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '1.25rem 1.5rem',
                background: 'var(--bark)',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.25rem', color: 'var(--parchment)', margin: 0 }}>
                  Your Order
                </h3>
                {cartCount > 0 && (
                  <span style={{
                    background: 'var(--ember)',
                    color: '#fff',
                    borderRadius: '50%',
                    width: '24px', height: '24px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                  }}>{cartCount}</span>
                )}
              </div>

              <div style={{ padding: '1.25rem 1.5rem' }}>
                {cart.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '2rem 0', color: 'var(--ash)' }}>
                    <div style={{ fontSize: '2rem', marginBottom: '0.75rem', opacity: 0.5 }}>☕</div>
                    <p style={{ fontSize: '0.875rem', lineHeight: 1.6 }}>Your order is empty.<br />Add items from the menu.</p>
                  </div>
                ) : (
                  <>
                    {cart.map((item) => (
                      <div key={item.id} style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        padding: '0.65rem 0',
                        borderBottom: '1px solid var(--smoke)',
                        fontSize: '0.875rem',
                      }}>
                        <span style={{ color: 'var(--oak)' }}>{item.qty}× {item.name}</span>
                        <span style={{ color: 'var(--bark)', fontWeight: 500 }}>£{(item.price * item.qty).toFixed(2)}</span>
                      </div>
                    ))}
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '1rem 0',
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: '1.25rem',
                    }}>
                      <span style={{ color: 'var(--bark)' }}>Total</span>
                      <span style={{ color: 'var(--ember)', fontWeight: 600 }}>£{total.toFixed(2)}</span>
                    </div>
                  </>
                )}
              </div>

              {cart.length > 0 && (
                <form onSubmit={handleSubmit} style={{ padding: '0 1.5rem 1.5rem', borderTop: '1px solid var(--smoke)' }}>
                  <div style={{ paddingTop: '1.25rem' }}>
                    <div className="form-group">
                      <label className="form-label">Your Name *</label>
                      <input className="form-input" required value={name} onChange={e => setName(e.target.value)} placeholder="Name for collection" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Email *</label>
                      <input className="form-input" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="For confirmation" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Preferred Pickup Time *</label>
                      <input className="form-input" required value={pickupTime} onChange={e => setPickupTime(e.target.value)} placeholder="e.g. 8:30am, 1pm" />
                    </div>

                    {/* Card payment section */}
                    <div style={{
                      marginBottom: '1rem',
                      padding: '1rem',
                      background: 'var(--parchment)',
                      borderRadius: '4px',
                      border: '1px solid var(--smoke)',
                    }}>
                      <div style={{
                        fontSize: '0.65rem',
                        fontWeight: 600,
                        letterSpacing: '0.15em',
                        textTransform: 'uppercase',
                        color: 'var(--ember)',
                        marginBottom: '0.85rem',
                      }}>
                        Card Payment
                      </div>
                      <div className="form-group" style={{ marginBottom: '0.75rem' }}>
                        <label className="form-label">Cardholder Name *</label>
                        <input
                          className="form-input"
                          required
                          value={cardHolder}
                          onChange={e => setCardHolder(e.target.value)}
                          placeholder="Name on card"
                          style={{ background: '#fff' }}
                        />
                      </div>
                      <div className="form-group" style={{ marginBottom: '0.75rem' }}>
                        <label className="form-label">Card Number *</label>
                        <input
                          className="form-input"
                          required
                          value={cardNumber}
                          onChange={e => {
                            const digits = e.target.value.replace(/\D/g, '').slice(0, 16)
                            setCardNumber(digits.replace(/(.{4})/g, '$1 ').trim())
                          }}
                          placeholder="1234 5678 9012 3456"
                          maxLength={19}
                          inputMode="numeric"
                          style={{ background: '#fff', letterSpacing: '0.05em', fontFamily: 'monospace' }}
                        />
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                        <div>
                          <label className="form-label">Expiry *</label>
                          <input
                            className="form-input"
                            required
                            value={cardExpiry}
                            onChange={e => {
                              const val = e.target.value.replace(/\D/g, '').slice(0, 4)
                              setCardExpiry(val.length > 2 ? `${val.slice(0, 2)}/${val.slice(2)}` : val)
                            }}
                            placeholder="MM/YY"
                            maxLength={5}
                            inputMode="numeric"
                            style={{ background: '#fff' }}
                          />
                        </div>
                        <div>
                          <label className="form-label">CVV *</label>
                          <input
                            className="form-input"
                            required
                            value={cardCvv}
                            onChange={e => setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                            placeholder="CVV"
                            maxLength={4}
                            inputMode="numeric"
                            style={{ background: '#fff' }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Notes (optional)</label>
                      <textarea className="form-textarea" rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Dietary needs, substitutions…" style={{ minHeight: '70px' }} />
                    </div>
                    <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={submitting}>
                      {submitting ? 'Placing Order…' : `Pay & Order · £${total.toFixed(2)}`}
                    </button>
                    <p style={{ fontSize: '0.72rem', color: 'var(--ash)', textAlign: 'center', marginTop: '0.75rem', lineHeight: 1.5 }}>
                      Your order will be confirmed by email within 15 minutes.
                    </p>
                  </div>
                </form>
              )}
            </div>
          </div>
          <style>{`
            @media (max-width: 900px) {
              .order-grid { grid-template-columns: 1fr !important; }
            }
          `}</style>
        </div>
      </section>
    </>
  )
}
