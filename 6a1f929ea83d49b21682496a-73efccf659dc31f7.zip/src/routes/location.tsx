import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/location')({
  component: LocationPage,
})

function LocationPage() {
  return (
    <>
      {/* Page Header */}
      <div style={{ background: 'var(--bark)', padding: '5rem 2.5rem 4rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 70% 40%, rgba(200,148,58,0.12) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>Find Us</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            Our Location
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '480px', lineHeight: 1.8 }}>
            We're in the heart of Ashford, three minutes from the International station.
            Come find us — there's always a good reason to.
          </p>
        </div>
      </div>

      {/* Map + Details */}
      <section className="section" style={{ paddingTop: '4rem' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4rem', alignItems: 'flex-start' }}>

            {/* Map */}
            <div>
              <div style={{
                borderRadius: '6px',
                overflow: 'hidden',
                border: '1px solid var(--smoke)',
                aspectRatio: '4/3',
                background: 'var(--parchment)',
                position: 'relative',
              }}>
                <iframe
                  src="https://www.openstreetmap.org/export/embed.html?bbox=0.849%2C51.135%2C0.879%2C51.155&layer=mapnik&marker=51.145%2C0.864"
                  width="100%"
                  height="100%"
                  style={{ border: 'none', display: 'block', width: '100%', height: '100%', position: 'absolute', inset: 0 }}
                  title="KoKio Bếp location map"
                  loading="lazy"
                />
              </div>
              <a
                href="https://www.openstreetmap.org/?mlat=51.145&mlon=0.864#map=15/51.145/0.864"
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-block', marginTop: '0.75rem', fontSize: '0.78rem', color: 'var(--ember)', letterSpacing: '0.06em' }}
              >
                Open in full map →
              </a>
            </div>

            {/* Details */}
            <div>
              <div style={{ marginBottom: '2.5rem' }}>
                <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '2rem', color: 'var(--bark)', marginBottom: '1.25rem' }}>
                  KoKio Bếp
                </h2>
                <div style={{
                  display: 'flex',
                  gap: '0.75rem',
                  alignItems: 'flex-start',
                  padding: '1.25rem',
                  background: 'var(--parchment)',
                  border: '1px solid var(--smoke)',
                  borderRadius: '4px',
                  marginBottom: '1rem',
                }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5" style={{ marginTop: '2px', flexShrink: 0 }}>
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
                  </svg>
                  <div>
                    <p style={{ margin: 0, color: 'var(--oak)', lineHeight: 1.8 }}>
                      KoKio Bếp<br />
                      Ashford, Kent<br />
                      United Kingdom
                    </p>
                  </div>
                </div>
              </div>

              {/* Transport */}
              <div style={{ marginBottom: '2.5rem' }}>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.4rem', color: 'var(--bark)', marginBottom: '1.25rem' }}>
                  Getting Here
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {[
                    {
                      title: 'By Train',
                      desc: 'Ashford International Station is a short walk away. Served by Southeastern and regular services from London St Pancras.',
                    },
                    {
                      title: 'By Car',
                      desc: 'Easily accessible in central Ashford. Street parking and nearby car parks available.',
                    },
                    {
                      title: 'Parking',
                      desc: 'Check local Ashford parking guides for the nearest car parks and on-street options close to the café.',
                    },
                  ].map((item) => (
                    <div key={item.title} style={{
                      display: 'flex',
                      gap: '1rem',
                      padding: '1.25rem',
                      border: '1px solid var(--smoke)',
                      borderRadius: '4px',
                      background: '#fff',
                    }}>
                      <div style={{ flexShrink: 0, width: '8px', height: '8px', borderRadius: '50%', background: 'var(--ember)', marginTop: '6px' }} />
                      <div>
                        <h4 style={{ fontFamily: "'Jost', sans-serif", fontSize: '0.8rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--bark)', margin: '0 0 0.35rem' }}>{item.title}</h4>
                        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--ash)', lineHeight: 1.65 }}>{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Opening hours */}
              <div>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.4rem', color: 'var(--bark)', marginBottom: '1rem' }}>
                  Opening Hours
                </h3>
                <div style={{ border: '1px solid var(--smoke)', borderRadius: '4px', overflow: 'hidden' }}>
                  {[
                    ['Monday', 'Closed'],
                    ['Tuesday', '7:00 am – 7:00 pm'],
                    ['Wednesday', '7:00 am – 7:00 pm'],
                    ['Thursday', '7:00 am – 7:00 pm'],
                    ['Friday', '7:00 am – 7:00 pm'],
                    ['Saturday', '7:00 am – 7:00 pm'],
                    ['Sunday', '8:00 am – 6:00 pm'],
                  ].map(([day, hours], i) => (
                    <div key={day} style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '0.75rem 1.25rem',
                      background: i % 2 === 0 ? '#fff' : 'var(--parchment)',
                      fontSize: '0.875rem',
                      borderBottom: i < 6 ? '1px solid var(--smoke)' : 'none',
                    }}>
                      <span style={{ color: 'var(--oak)' }}>{day}</span>
                      <span style={{ color: hours === 'Closed' ? 'var(--ash)' : 'var(--bark)', fontWeight: 500 }}>{hours}</span>
                    </div>
                  ))}
                </div>
                <p style={{ margin: '0.75rem 0 0', fontSize: '0.78rem', color: 'var(--ash)', lineHeight: 1.6 }}>
                  Kitchen closes 30 minutes before closing time. Last orders for hot food at stated kitchen times.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Accessibility */}
      <section className="section-sm" style={{ background: 'var(--parchment)', borderTop: '1px solid var(--smoke)' }}>
        <div className="container">
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', marginBottom: '1.5rem' }}>
            Accessibility
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem' }}>
            {[
              'Step-free access from street level',
              'Accessible toilet on the ground floor',
              'High-visibility menus available on request',
              'Induction loop available',
              'Pushchair & pram friendly',
              'Guide dogs warmly welcome',
            ].map((item) => (
              <div key={item} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                <div style={{
                  width: '20px', height: '20px', minWidth: '20px',
                  borderRadius: '50%',
                  background: 'rgba(196,98,45,0.1)',
                  border: '1.5px solid var(--ember)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  marginTop: '1px',
                }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="3">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                </div>
                <span style={{ fontSize: '0.875rem', color: 'var(--oak)', lineHeight: 1.6 }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
