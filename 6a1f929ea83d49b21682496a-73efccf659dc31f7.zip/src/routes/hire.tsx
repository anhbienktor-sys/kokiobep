import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/hire')({
  component: HirePage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

const eventTypes = [
  'Birthday celebration',
  'Anniversary dinner',
  'Wedding reception',
  'Baby shower',
  'Corporate dinner',
  'Team lunch or event',
  'Leaving party',
  'Retirement celebration',
  'Book club or society',
  'Catering only (offsite)',
  'Other',
]

function HirePage() {
  const [fields, setFields] = useState({
    name: '', email: '', phone: '', company: '',
    'event-type': '', date: '', guests: '', budget: '',
    'start-time': '', 'end-time': '',
    catering: '', 'dietary-notes': '', message: '',
  })
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    await fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'hire', ...fields }),
    })
    setSubmitting(false)
    setSubmitted(true)
  }

  return (
    <>
      {/* Page Header */}
      <div style={{
        background: 'var(--bark)',
        padding: '5rem 2.5rem 4rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 30% 70%, rgba(196,98,45,0.18) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>Exclusive Use</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            Private Hire
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '520px', lineHeight: 1.8 }}>
            From intimate birthday lunches to full-venue celebrations, we open KoKio Bếp exclusively for your event.
            Bespoke Vietnamese menus, warm hospitality, and a team that genuinely cares.
          </p>
        </div>
      </div>

      {/* What's included */}
      <section className="section-sm" style={{ background: 'var(--parchment)', borderBottom: '1px solid var(--smoke)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            {[
              { label: 'Capacity', value: 'Up to 60 seated\nUp to 80 standing' },
              { label: 'Hire hours', value: 'Evenings from 6:30pm\nWeekends all day' },
              { label: 'Catering', value: 'Bespoke Vietnamese menus\nCatering offsite available' },
              { label: 'Bar', value: 'Full bar with natural wines\nCocktails & soft drinks' },
              { label: 'AV', value: 'Bluetooth audio\nProjector available' },
              { label: 'Pricing', value: 'Venue hire from £400\n+ food & drink packages' },
            ].map((item) => (
              <div key={item.label} style={{ textAlign: 'center', padding: '1.5rem 1rem' }}>
                <div style={{ fontFamily: "'Jost', sans-serif", fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--ember)', marginBottom: '0.6rem' }}>{item.label}</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.15rem', color: 'var(--bark)', lineHeight: 1.5, whiteSpace: 'pre-line' }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Event Types */}
      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: '5rem', alignItems: 'flex-start' }}>

            <div>
              <div className="label">The Space</div>
              <h2 className="heading-xl" style={{ marginBottom: '1.5rem' }}>
                For every kind of<br />
                <em style={{ color: 'var(--ember)', fontStyle: 'italic' }}>gathering.</em>
              </h2>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '1.5rem' }}>
                We've hosted everything from 12-person birthday lunches to full venue celebrations. The café transforms beautifully for private events — warm lighting, good acoustics, and a Vietnamese kitchen that rises to any brief.
              </p>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '2rem' }}>
                Every hire includes a dedicated point of contact from enquiry to event day. We're personally invested in making your event memorable.
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {eventTypes.slice(0, 8).map((type) => (
                  <div key={type} style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', fontSize: '0.875rem', color: 'var(--oak)' }}>
                    <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--ember)', flexShrink: 0 }} />
                    {type}
                  </div>
                ))}
              </div>

              {/* Testimonial */}
              <div style={{
                marginTop: '2.5rem',
                padding: '1.5rem',
                background: 'var(--bark)',
                borderRadius: '4px',
                position: 'relative',
              }}>
                <div style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '3rem',
                  color: 'var(--gold)',
                  lineHeight: 0.5,
                  marginBottom: '0.75rem',
                  opacity: 0.6,
                }}>"</div>
                <p style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', color: 'var(--parchment)', lineHeight: 1.6, margin: '0 0 1rem' }}>
                  Our guests are still talking about the food. The bánh mì were gone within minutes and the phở had everyone asking for more. Nothing felt like event catering — it felt personal and special.
                </p>
                <div style={{ fontSize: '0.75rem', color: 'var(--ash)', letterSpacing: '0.08em' }}>
                  Sarah & Tom Bishop · Birthday Celebration, April 2026
                </div>
              </div>
            </div>

            {/* Quote Request Form */}
            <div style={{
              background: '#fff',
              border: '1px solid var(--smoke)',
              borderRadius: '6px',
              overflow: 'hidden',
            }}>
              <div style={{ padding: '1.75rem 2rem', background: 'var(--parchment)', borderBottom: '1px solid var(--smoke)' }}>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', margin: 0 }}>
                  Request a Quote
                </h3>
                <p style={{ margin: '0.5rem 0 0', fontSize: '0.875rem', color: 'var(--ash)' }}>
                  We'll come back to you within one working day with availability and a tailored quote.
                </p>
              </div>

              <div style={{ padding: '2rem' }}>
                {submitted ? (
                  <div style={{ textAlign: 'center', padding: '2.5rem 1rem' }}>
                    <div style={{
                      width: '56px', height: '56px', borderRadius: '50%',
                      background: 'rgba(196,98,45,0.1)', border: '2px solid var(--ember)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem',
                    }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', marginBottom: '0.75rem' }}>
                      Enquiry received.
                    </h3>
                    <p style={{ color: 'var(--ash)', lineHeight: 1.8 }}>
                      Thank you, {fields.name}. We'll review the details and be in touch at <strong>{fields.email}</strong> within one working day.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <input type="hidden" name="form-name" value="hire" />
                    <input type="text" name="bot-field" style={{ display: 'none' }} />

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                      <div>
                        <label className="form-label">Name *</label>
                        <input className="form-input" name="name" required value={fields.name} onChange={handleChange} placeholder="Your full name" />
                      </div>
                      <div>
                        <label className="form-label">Email *</label>
                        <input className="form-input" name="email" type="email" required value={fields.email} onChange={handleChange} placeholder="your@email.com" />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                      <div>
                        <label className="form-label">Phone</label>
                        <input className="form-input" name="phone" value={fields.phone} onChange={handleChange} placeholder="+44 …" />
                      </div>
                      <div>
                        <label className="form-label">Company / Organisation</label>
                        <input className="form-input" name="company" value={fields.company} onChange={handleChange} placeholder="If applicable" />
                      </div>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Event Type *</label>
                      <select className="form-select" name="event-type" required value={fields['event-type']} onChange={handleChange}>
                        <option value="">Select event type</option>
                        {eventTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                      <div>
                        <label className="form-label">Preferred Date *</label>
                        <input className="form-input" name="date" type="date" required value={fields.date} onChange={handleChange} />
                      </div>
                      <div>
                        <label className="form-label">Number of Guests *</label>
                        <input className="form-input" name="guests" type="number" min="10" max="80" required value={fields.guests} onChange={handleChange} placeholder="e.g. 40" />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                      <div>
                        <label className="form-label">Start Time</label>
                        <input className="form-input" name="start-time" type="time" value={fields['start-time']} onChange={handleChange} />
                      </div>
                      <div>
                        <label className="form-label">End Time</label>
                        <input className="form-input" name="end-time" type="time" value={fields['end-time']} onChange={handleChange} />
                      </div>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Catering Requirements</label>
                      <select className="form-select" name="catering" value={fields.catering} onChange={handleChange}>
                        <option value="">Select option</option>
                        <option value="Full catering (three courses)">Full catering — three courses</option>
                        <option value="Sharing / grazing menu">Sharing / grazing menu</option>
                        <option value="Canapés and drinks only">Canapés and drinks only</option>
                        <option value="Afternoon tea">Afternoon tea</option>
                        <option value="Breakfast / brunch spread">Breakfast / brunch spread</option>
                        <option value="Venue only (self-catered)">Venue only — self-catered</option>
                        <option value="Offsite catering only">Offsite catering only</option>
                        <option value="Not sure yet">Not sure yet</option>
                      </select>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Budget Range</label>
                      <select className="form-select" name="budget" value={fields.budget} onChange={handleChange}>
                        <option value="">Prefer not to say</option>
                        <option value="Under £500">Under £500</option>
                        <option value="£500 – £1,000">£500 – £1,000</option>
                        <option value="£1,000 – £2,500">£1,000 – £2,500</option>
                        <option value="£2,500 – £5,000">£2,500 – £5,000</option>
                        <option value="£5,000+">£5,000+</option>
                      </select>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Dietary Notes</label>
                      <input className="form-input" name="dietary-notes" value={fields['dietary-notes']} onChange={handleChange} placeholder="Known allergies, vegan guests, etc." />
                    </div>

                    <div style={{ marginBottom: '1.5rem' }}>
                      <label className="form-label">Anything else we should know?</label>
                      <textarea className="form-textarea" name="message" rows={3} value={fields.message} onChange={handleChange} placeholder="Theme, special requests, vision for the event…" />
                    </div>

                    <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={submitting}>
                      {submitting ? 'Sending Enquiry…' : 'Request a Quote'}
                    </button>
                    <p style={{ fontSize: '0.72rem', color: 'var(--ash)', textAlign: 'center', marginTop: '0.75rem' }}>
                      We'll reply within one working day with availability, menu ideas, and pricing.
                    </p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Catering offsite */}
      <section className="section-sm" style={{ background: 'var(--bark)' }}>
        <div className="container" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4rem', alignItems: 'center' }}>
          <div>
            <div className="label" style={{ color: 'var(--gold)' }}>Beyond our doors</div>
            <h2 className="heading-xl" style={{ color: 'var(--parchment)', marginBottom: '1.25rem' }}>
              Catering & offsite events
            </h2>
            <p style={{ color: 'var(--smoke)', lineHeight: 1.8, marginBottom: '1rem' }}>
              Can't come to us? We'll come to you. Our catering team serves across Kent and East Sussex — corporate offices, private homes, marquees, and outdoor events.
            </p>
            <p style={{ color: 'var(--ash)', fontSize: '0.875rem', lineHeight: 1.8 }}>
              Minimum party size of 20 for offsite catering. Enquire via the quote form above.
            </p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            {[
              'Canapes & drinks receptions',
              'Seated dinner service',
              'Wedding & event catering',
              'Corporate hospitality',
              'Afternoon tea service',
              'Breakfast & brunch spreads',
            ].map((item) => (
              <div key={item} style={{
                padding: '1rem 1.25rem',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '4px',
                fontSize: '0.82rem',
                color: 'var(--smoke)',
                lineHeight: 1.5,
              }}>{item}</div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
