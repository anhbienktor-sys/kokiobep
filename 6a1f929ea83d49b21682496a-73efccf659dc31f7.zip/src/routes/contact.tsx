import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

function ContactPage() {
  const [fields, setFields] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
    if (errors[e.target.name]) setErrors({ ...errors, [e.target.name]: '' })
  }

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!fields.name.trim()) newErrors.name = 'Please enter your name.'
    if (!fields.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) newErrors.email = 'Please enter a valid email address.'
    if (!fields.message.trim()) newErrors.message = 'Please write a message.'
    return newErrors
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors = validate()
    if (Object.keys(newErrors).length > 0) { setErrors(newErrors); return }
    setSubmitting(true)
    await fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'contact', ...fields }),
    })
    setSubmitting(false)
    setSubmitted(true)
  }

  return (
    <>
      {/* Page Header */}
      <div style={{ background: 'var(--parchment)', padding: '5rem 2.5rem 4rem', borderBottom: '1px solid var(--smoke)' }}>
        <div className="container">
          <div className="label animate-fade-up">Get in Touch</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ marginBottom: '1rem' }}>
            Contact Us
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--ash)', maxWidth: '480px', lineHeight: 1.8 }}>
            Questions, feedback, special requests — we'd love to hear from you.
            We aim to respond within one working day.
          </p>
        </div>
      </div>

      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: '5rem', alignItems: 'flex-start' }}>

            {/* Form */}
            <div>
              {submitted ? (
                <div style={{
                  background: 'var(--parchment)',
                  border: '1px solid var(--smoke)',
                  borderRadius: '6px',
                  padding: '3rem',
                  textAlign: 'center',
                }}>
                  <div style={{
                    width: '56px', height: '56px',
                    borderRadius: '50%',
                    background: 'rgba(196,98,45,0.1)',
                    border: '2px solid var(--ember)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 1.5rem',
                  }}>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '2rem', color: 'var(--bark)', marginBottom: '0.75rem' }}>
                    Message sent.
                  </h3>
                  <p style={{ color: 'var(--ash)', lineHeight: 1.8 }}>
                    Thank you, {fields.name}. We'll be back in touch at <strong>{fields.email}</strong> within one working day.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Full Name *</label>
                      <input
                        className="form-input"
                        name="name"
                        value={fields.name}
                        onChange={handleChange}
                        placeholder="Your name"
                        style={errors.name ? { borderColor: '#c0392b' } : {}}
                      />
                      {errors.name && <span style={{ fontSize: '0.75rem', color: '#c0392b', marginTop: '0.35rem', display: 'block' }}>{errors.name}</span>}
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Email Address *</label>
                      <input
                        className="form-input"
                        name="email"
                        type="email"
                        value={fields.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        style={errors.email ? { borderColor: '#c0392b' } : {}}
                      />
                      {errors.email && <span style={{ fontSize: '0.75rem', color: '#c0392b', marginTop: '0.35rem', display: 'block' }}>{errors.email}</span>}
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginTop: '1.25rem' }}>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Phone (optional)</label>
                      <input className="form-input" name="phone" value={fields.phone} onChange={handleChange} placeholder="+44 …" />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Subject</label>
                      <select className="form-select" name="subject" value={fields.subject} onChange={handleChange}>
                        <option value="">Select a topic</option>
                        <option value="General enquiry">General enquiry</option>
                        <option value="Booking / reservation">Booking / reservation</option>
                        <option value="Private hire">Private hire</option>
                        <option value="Catering enquiry">Catering enquiry</option>
                        <option value="Feedback">Feedback</option>
                        <option value="Press / media">Press / media</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group" style={{ marginTop: '1.25rem' }}>
                    <label className="form-label">Message *</label>
                    <textarea
                      className="form-textarea"
                      name="message"
                      value={fields.message}
                      onChange={handleChange}
                      placeholder="How can we help?"
                      rows={5}
                      style={errors.message ? { borderColor: '#c0392b' } : {}}
                    />
                    {errors.message && <span style={{ fontSize: '0.75rem', color: '#c0392b', marginTop: '0.35rem', display: 'block' }}>{errors.message}</span>}
                  </div>
                  {/* Honeypot */}
                  <input type="hidden" name="form-name" value="contact" />
                  <input type="text" name="bot-field" style={{ display: 'none' }} />
                  <button type="submit" className="btn-primary" disabled={submitting} style={{ marginTop: '0.5rem' }}>
                    {submitting ? 'Sending…' : 'Send Message'}
                  </button>
                </form>
              )}
            </div>

            {/* Info panels */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {[
                {
                  icon: (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
                    </svg>
                  ),
                  title: 'Address',
                  content: 'KoKio Bếp\nAshford, Kent',
                  link: '/location',
                  linkLabel: 'Get directions',
                },
                {
                  icon: (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5">
                      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.42 13.5 19.79 19.79 0 01.36 4.92a2 2 0 012-2.18h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 10.36a16 16 0 006.73 6.73l1.7-1.7a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
                    </svg>
                  ),
                  title: 'Phone',
                  content: '+44 1234 567 890',
                  link: 'tel:+441234567890',
                  linkLabel: 'Call us',
                },
                {
                  icon: (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                    </svg>
                  ),
                  title: 'Email',
                  content: 'hello@kokiobep.co.uk',
                  link: 'mailto:hello@kokiobep.co.uk',
                  linkLabel: 'Send an email',
                },
                {
                  icon: (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="1.5">
                      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                    </svg>
                  ),
                  title: 'Opening Hours',
                  content: 'Mon–Fri 8am–6pm\nSat 9am–6pm · Sun 9am–5pm',
                },
              ].map((item) => (
                <div key={item.title} style={{
                  background: 'var(--parchment)',
                  border: '1px solid var(--smoke)',
                  borderRadius: '4px',
                  padding: '1.5rem',
                  display: 'flex',
                  gap: '1rem',
                  alignItems: 'flex-start',
                }}>
                  <div style={{ marginTop: '2px', flexShrink: 0 }}>{item.icon}</div>
                  <div>
                    <h4 style={{ fontFamily: "'Jost', sans-serif", fontSize: '0.72rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ash)', margin: '0 0 0.35rem' }}>{item.title}</h4>
                    <p style={{ margin: 0, color: 'var(--oak)', fontSize: '0.9rem', lineHeight: 1.7, whiteSpace: 'pre-line' }}>{item.content}</p>
                    {item.link && (
                      <a href={item.link.startsWith('/') ? undefined : item.link}
                        style={{ fontSize: '0.78rem', color: 'var(--ember)', letterSpacing: '0.06em', marginTop: '0.5rem', display: 'inline-block' }}>
                        {item.linkLabel} →
                      </a>
                    )}
                  </div>
                </div>
              ))}

              <div style={{
                background: 'var(--bark)',
                borderRadius: '4px',
                padding: '1.75rem',
                color: 'var(--smoke)',
              }}>
                <h4 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.25rem', color: 'var(--parchment)', marginBottom: '0.75rem' }}>
                  For private hire & events
                </h4>
                <p style={{ fontSize: '0.875rem', lineHeight: 1.7, margin: '0 0 1.25rem', opacity: 0.8 }}>
                  Enquiries about exclusive use, catering packages, and large group bookings are best handled through our hire request form.
                </p>
                <Link to="/hire" className="btn-ghost" style={{ borderColor: 'rgba(255,255,255,0.3)', color: 'var(--parchment)', fontSize: '0.75rem', padding: '0.6rem 1.25rem' }}>
                  Private Hire Enquiry
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
