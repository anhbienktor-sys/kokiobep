import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/careers')({
  component: CareersPage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

const roles = [
  {
    title: 'Barista',
    icon: '☕',
    type: 'Full-time / Part-time',
    desc: 'We\'re looking for a passionate barista who loves both Vietnamese and western coffee. You\'ll be crafting everything from phin-brewed classics to silky lattes and seasonal drinks. Attention to detail, warmth with customers, and a genuine love for coffee are essential.',
    requirements: [
      'Barista experience (Vietnamese or specialty coffee a bonus)',
      'Friendly, customer-first attitude',
      'Ability to work in a fast-paced café environment',
      'Flexible availability including weekends',
    ],
  },
  {
    title: 'Kitchen Staff',
    icon: '🍜',
    type: 'Full-time / Part-time',
    desc: 'Join our kitchen team and help bring authentic Vietnamese cooking to Ashford. You\'ll be preparing fresh dishes including bánh mì, phở, bún bò Huế, spring rolls, and more — everything made from scratch daily.',
    requirements: [
      'Kitchen or food prep experience preferred',
      'Interest in Vietnamese cuisine',
      'Ability to work cleanly and efficiently under pressure',
      'Food hygiene certificate (or willingness to obtain one)',
    ],
  },
  {
    title: 'Café Runner',
    icon: '🫶',
    type: 'Part-time / Weekend',
    desc: 'A vital part of the front-of-house team — you\'ll keep the café running smoothly by running food and drinks, clearing tables, supporting the barista station, and ensuring every guest feels looked after. Great for someone starting in hospitality.',
    requirements: [
      'Energetic, reliable, and a team player',
      'Warm and welcoming with guests',
      'No experience required — full training provided',
      'Availability on weekends preferred',
    ],
  },
]

function CareersPage() {
  const [fields, setFields] = useState({ name: '', email: '', phone: '', position: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    await fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'careers', ...fields }),
    })
    setSubmitting(false)
    setSubmitted(true)
  }

  return (
    <>
      {/* Page Header */}
      <div style={{
        background: 'var(--bark)',
        padding: '5rem 2.5rem 4rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 30% 70%, rgba(196,98,45,0.18) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>Join the Team</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            Work With Us
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '520px', lineHeight: 1.8 }}>
            We're building a team that genuinely cares — about the food, the coffee, and the people we serve. If that sounds like you, we'd love to hear from you.
          </p>
        </div>
      </div>

      {/* Why work here */}
      <section className="section-sm" style={{ background: 'var(--parchment)', borderBottom: '1px solid var(--smoke)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            {[
              { label: 'Team culture', value: 'Warm, supportive\nand collaborative' },
              { label: 'Food & drink', value: 'Staff meals\nand drinks on shift' },
              { label: 'Hours', value: 'Tue – Sat, 7am – 7pm\nSun, 8am – 6pm' },
              { label: 'Location', value: 'Ashford, Kent\nEasy transport links' },
              { label: 'Training', value: 'Full training\nprovided for all roles' },
              { label: 'Growth', value: 'Opportunities to grow\nwith the business' },
            ].map((item) => (
              <div key={item.label} style={{ textAlign: 'center', padding: '1.5rem 1rem' }}>
                <div style={{ fontFamily: "'Jost', sans-serif", fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--ember)', marginBottom: '0.6rem' }}>{item.label}</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.15rem', color: 'var(--bark)', lineHeight: 1.5, whiteSpace: 'pre-line' }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open Roles */}
      <section className="section">
        <div className="container">
          <div style={{ marginBottom: '3rem' }}>
            <div className="label">Current Openings</div>
            <h2 className="heading-xl">Roles we're hiring for</h2>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', marginBottom: '5rem' }}>
            {roles.map((role) => (
              <div key={role.title} style={{
                background: '#fff',
                border: '1px solid var(--smoke)',
                borderRadius: '6px',
                overflow: 'hidden',
                display: 'grid',
                gridTemplateColumns: '1fr 1.4fr',
                transition: 'box-shadow 0.2s',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 32px rgba(58,37,16,0.1)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = '' }}
              >
                <div style={{
                  padding: '2.5rem',
                  background: 'var(--parchment)',
                  borderRight: '1px solid var(--smoke)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                }}>
                  <div>
                    <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>{role.icon}</div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '2rem', color: 'var(--bark)', marginBottom: '0.5rem', lineHeight: 1.1 }}>
                      {role.title}
                    </h3>
                    <div style={{
                      display: 'inline-block',
                      background: 'rgba(196,98,45,0.1)',
                      border: '1px solid rgba(196,98,45,0.2)',
                      borderRadius: '2px',
                      padding: '0.25rem 0.75rem',
                      fontSize: '0.72rem',
                      fontWeight: 500,
                      letterSpacing: '0.1em',
                      textTransform: 'uppercase',
                      color: 'var(--ember)',
                      marginTop: '0.25rem',
                    }}>
                      {role.type}
                    </div>
                  </div>
                  <div style={{
                    marginTop: '2rem',
                    paddingTop: '1.5rem',
                    borderTop: '1px solid var(--smoke)',
                  }}>
                    <div style={{ fontSize: '0.7rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ash)', marginBottom: '0.75rem' }}>
                      Based in
                    </div>
                    <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', color: 'var(--bark)' }}>
                      Ashford, Kent
                    </div>
                  </div>
                </div>

                <div style={{ padding: '2.5rem' }}>
                  <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '1.75rem', fontSize: '0.9rem' }}>
                    {role.desc}
                  </p>
                  <div>
                    <div style={{ fontSize: '0.7rem', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ash)', marginBottom: '0.85rem' }}>
                      What we're looking for
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                      {role.requirements.map((req) => (
                        <div key={req} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start', fontSize: '0.875rem', color: 'var(--oak)' }}>
                          <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--ember)', flexShrink: 0, marginTop: '7px' }} />
                          {req}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Application Form */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '5rem', alignItems: 'flex-start' }}>
            <div>
              <div className="label">Apply Now</div>
              <h2 className="heading-xl" style={{ marginBottom: '1.25rem' }}>
                Sounds like you?
              </h2>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, marginBottom: '1rem' }}>
                Send us a message and we'll be in touch. No lengthy application forms — just tell us a bit about yourself and which role you're interested in.
              </p>
              <p style={{ color: 'var(--ash)', lineHeight: 1.8, fontSize: '0.875rem' }}>
                We aim to reply within two working days. Even if we don't have an opening right now, we keep great applications on file.
              </p>
            </div>

            <div style={{ background: 'var(--parchment)', border: '1px solid var(--smoke)', borderRadius: '6px', overflow: 'hidden' }}>
              <div style={{ padding: '1.75rem 2rem', background: '#fff', borderBottom: '1px solid var(--smoke)' }}>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', margin: 0 }}>
                  Apply for a Role
                </h3>
                <p style={{ margin: '0.5rem 0 0', fontSize: '0.875rem', color: 'var(--ash)' }}>
                  We'll come back to you within two working days.
                </p>
              </div>

              <div style={{ padding: '2rem' }}>
                {submitted ? (
                  <div style={{ textAlign: 'center', padding: '2.5rem 1rem' }}>
                    <div style={{
                      width: '56px', height: '56px', borderRadius: '50%',
                      background: 'rgba(196,98,45,0.1)', border: '2px solid var(--ember)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem',
                    }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--ember)" strokeWidth="2">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', color: 'var(--bark)', marginBottom: '0.75rem' }}>
                      Application received.
                    </h3>
                    <p style={{ color: 'var(--ash)', lineHeight: 1.8 }}>
                      Thanks {fields.name} — we've received your application and will be in touch at <strong>{fields.email}</strong> shortly.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <input type="hidden" name="form-name" value="careers" />
                    <input type="text" name="bot-field" style={{ display: 'none' }} />

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                      <div>
                        <label className="form-label">Name *</label>
                        <input className="form-input" name="name" required value={fields.name} onChange={handleChange} placeholder="Your full name" />
                      </div>
                      <div>
                        <label className="form-label">Email *</label>
                        <input className="form-input" name="email" type="email" required value={fields.email} onChange={handleChange} placeholder="your@email.com" />
                      </div>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Phone</label>
                      <input className="form-input" name="phone" value={fields.phone} onChange={handleChange} placeholder="+44 …" />
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label className="form-label">Position you're applying for *</label>
                      <select className="form-select" name="position" required value={fields.position} onChange={handleChange}>
                        <option value="">Select a role</option>
                        <option value="Barista">Barista</option>
                        <option value="Kitchen Staff">Kitchen Staff</option>
                        <option value="Café Runner">Café Runner</option>
                      </select>
                    </div>

                    <div style={{ marginBottom: '1.5rem' }}>
                      <label className="form-label">Tell us about yourself *</label>
                      <textarea className="form-textarea" name="message" rows={4} required value={fields.message} onChange={handleChange} placeholder="A bit about your experience, why you'd like to join us, and your availability…" />
                    </div>

                    <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={submitting}>
                      {submitting ? 'Sending Application…' : 'Send Application'}
                    </button>
                    <p style={{ fontSize: '0.72rem', color: 'var(--ash)', textAlign: 'center', marginTop: '0.75rem' }}>
                      We reply to every application within two working days.
                    </p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
