import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import menuItems, { menuCategories, type MenuItem } from '@/data/menu'

export const Route = createFileRoute('/menu')({
  component: MenuPage,
})

function DietBadges({ item }: { item: MenuItem }) {
  return (
    <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap', marginTop: '0.6rem' }}>
      {item.vegan && <span className="badge badge-ember">Vegan</span>}
      {item.vegetarian && !item.vegan && <span className="badge">Vegetarian</span>}
      {item.glutenFree && <span className="badge badge-gold">Gluten Free</span>}
      {item.popular && <span className="badge" style={{ background: 'rgba(196,98,45,0.08)', color: 'var(--ember)' }}>Chef's Favourite</span>}
    </div>
  )
}

function MenuPage() {
  const [activeCategory, setActiveCategory] = useState('coffee')

  const filtered = menuItems.filter((item) => item.category === activeCategory)
  const currentCat = menuCategories.find((c) => c.id === activeCategory)

  const categoryNotes: Record<string, string> = {
    coffee: 'All Vietnamese coffees brewed using the traditional phin drip method. Egg coffee and coconut coffee freshly prepared to order. Ask about our daily specials.',
    'western-coffee': 'Espresso drinks available with whole milk, oat, or coconut milk. Decaf available on request.',
    'banh-mi': 'All bánh mì served on freshly baked crispy baguette with pickled daikon & carrot, cucumber, fresh chilli, and coriander. Available until sold out.',
    kitchen: 'Freshly prepared each day. Phở broth is slow-cooked for 12 hours. Please allow a few extra minutes for made-to-order dishes.',
    desserts: 'Vietnamese desserts and snacks made fresh daily. Seasonal ingredients used where available. Ask staff for today\'s specials.',
  }

  return (
    <>
      {/* Page Header */}
      <div style={{
        background: 'var(--bark)',
        padding: '5rem 2.5rem 4rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse at 80% 50%, rgba(196,98,45,0.15) 0%, transparent 60%)',
        }} />
        <div className="container" style={{ position: 'relative' }}>
          <div className="label animate-fade-up" style={{ color: 'var(--gold)' }}>KoKio Bếp</div>
          <h1 className="heading-display animate-fade-up delay-100" style={{ color: 'var(--parchment)', marginBottom: '1rem' }}>
            Our Menu
          </h1>
          <p className="animate-fade-up delay-200" style={{ color: 'var(--smoke)', maxWidth: '520px', lineHeight: 1.8 }}>
            Vietnamese coffee brewed the traditional way, bánh mì made fresh daily, and kitchen dishes prepared to order.
            Please let us know about any dietary requirements — we're happy to help.
          </p>
        </div>
      </div>

      {/* Category Nav */}
      <div style={{
        position: 'sticky',
        top: 'var(--nav-height)',
        background: 'rgba(250,246,240,0.97)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid var(--smoke)',
        zIndex: 50,
      }}>
        <div className="container" style={{ overflowX: 'auto' }}>
          <div style={{ display: 'flex', gap: '0', minWidth: 'max-content' }}>
            {menuCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: '1.1rem 1.5rem',
                  fontSize: '0.78rem',
                  fontWeight: 500,
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: activeCategory === cat.id ? 'var(--ember)' : 'var(--ash)',
                  borderBottom: activeCategory === cat.id ? '2px solid var(--ember)' : '2px solid transparent',
                  cursor: 'pointer',
                  transition: 'color 0.2s, border-color 0.2s',
                  whiteSpace: 'nowrap',
                }}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <section className="section">
        <div className="container">
          <div style={{ marginBottom: '2.5rem' }}>
            <h2 className="heading-xl" style={{ marginBottom: '0.5rem' }}>{currentCat?.label}</h2>
            <p style={{ color: 'var(--ash)', fontSize: '0.875rem' }}>{categoryNotes[activeCategory]}</p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
            gap: '1px',
            background: 'var(--smoke)',
            border: '1px solid var(--smoke)',
            borderRadius: '6px',
            overflow: 'hidden',
          }}>
            {filtered.map((item) => (
              <div
                key={item.id}
                style={{
                  background: '#fff',
                  padding: '1.75rem',
                  transition: 'background 0.15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--parchment)')}
                onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
                  <h3 style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontSize: '1.2rem',
                    color: 'var(--bark)',
                    lineHeight: 1.3,
                  }}>{item.name}</h3>
                  <span style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontSize: '1.15rem',
                    color: 'var(--ember)',
                    fontWeight: 600,
                    whiteSpace: 'nowrap',
                    paddingTop: '2px',
                  }}>£{item.price.toFixed(2)}</span>
                </div>
                <p style={{ margin: '0.5rem 0 0', fontSize: '0.85rem', color: 'var(--ash)', lineHeight: 1.65 }}>
                  {item.description}
                </p>
                <DietBadges item={item} />
              </div>
            ))}
          </div>

          {/* Allergens note */}
          <div style={{
            marginTop: '3rem',
            padding: '1.5rem',
            background: 'var(--parchment)',
            border: '1px solid var(--smoke)',
            borderRadius: '4px',
            display: 'flex',
            gap: '1rem',
            alignItems: 'flex-start',
          }}>
            <div style={{
              width: '20px', height: '20px', minWidth: '20px',
              borderRadius: '50%',
              border: '1.5px solid var(--ash)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '0.7rem',
              color: 'var(--ash)',
              marginTop: '2px',
              fontWeight: 600,
            }}>i</div>
            <p style={{ margin: 0, fontSize: '0.82rem', color: 'var(--ash)', lineHeight: 1.7 }}>
              <strong style={{ color: 'var(--oak)' }}>Allergens & Dietary Needs.</strong>{' '}
              Our kitchen handles all 14 major allergens. If you have a food allergy or intolerance, please speak to a member of staff before ordering.
              We will do our best to accommodate requirements, but cannot guarantee a fully allergen-free environment.
              Full allergen information is available on request.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}
